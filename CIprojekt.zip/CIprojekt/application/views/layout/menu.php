<?php
echo anchor('#', 'Odkaz1');
echo anchor('#', 'Odkaz2');
echo anchor('#', 'Odkaz3');



?>