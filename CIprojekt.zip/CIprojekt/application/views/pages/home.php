<html>
    <head>
        <title>Domů</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="css/bootstrap.css" rel="stylesheet" type="text/css"/>
        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
        <link rel="stylesheet/less" type="text/css" href="styles.less">
        <script src="less.js" type="text/javascript"></script>
    </head>
    <body>
        <style>
div {
  padding: 8px;
}

h1 {
  border: 1px solid gray;
  text-align: center;
  text-transform: uppercase;
  color: #4CAF50;
}

p {
  text-indent: 50px;
  text-align: justify;
  letter-spacing: 3px;
}

a {
  text-decoration: none;
  color: #008CBA;
}
</style>
</head>
<body>

<div>
  <h1>Seznam četby ke státní maturitě</h1>
  <p>Vítejte na webu, který obsahuje knihy k maturitní četbě z českého jazyka. Momentálně se nacházíme na stránce domů, na stránce autoři jsou zobrazeny všechny kategorie, na které se dá kliknout, po té co na ně kliknete, zobrazí se vám seznam autorů a děl které napsali v daném období.
      Na stránce díla jsou autoři, jejich díla a anotace knihy (anotace obsahuje pouze text z lorem ipsum).
      
      
      
</div>   
    
    </body>
</html>